# Mindmap

`mindmap.html` is the whole app: one file, no install, no account, no internet.

**Open it** by double-clicking. It works offline — everything, including the icons, is inside that
one file. Nothing is ever sent anywhere.

The top bar shows **Saved locally** — hover it to see exactly where your work is kept, and what
that does and does not guarantee.

**Your maps live in your own browser** (`localStorage`), not in the file and not on a server. That
means:

- Maps you make are visible only to you, on that browser, on that machine.
- Sending this file to someone else sends the app, never your maps.
- Clearing site data, or opening it in a different browser, gives you an empty start.

So for anything you care about, use **Export ▾ → JSON**. That file is the real backup, and
**Import JSON** brings it back — including on someone else's copy, which is how you hand a map to
another person.

Chrome and Firefox both autosave for a file opened from disk, so double-clicking is enough.

If the top bar says **No autosave**, the page was not opened as a real page — usually it is still an
attachment or a preview, which browsers give no origin and therefore no storage. Save the file
somewhere on your computer first, then open that file. (Safari does not allow storage for local
files at all; use Chrome or Firefox.)

## Getting started

The map you see on first run explains itself. The short version:

| | |
|---|---|
| `Tab` | new child |
| `Enter` | new sibling |
| `Space` | rename — or just start typing |
| `⌘Enter` | notes (markdown) |
| `⌘L` | connect two nodes across branches |
| `?` | every shortcut |

Drag a node above or below another to reorder it, or onto it to make it a child.
